package model;

public class Job {
    int Job_Id;
    int HR_Id;
    String HR_Name;
    String Company_Name; 
    String Required_Skills;
    String Job_Post ;
    String Location ;
    Double Salary;
    String Qualifications ;
    
    public Job(int hR_Id, String job_Post, String location, Double salary, String qualifications) {
        HR_Id = hR_Id;
        Job_Post = job_Post;
        Location = location;
        Salary = salary;
        Qualifications = qualifications;
    }
    public Job(int hR_Id, String hR_Name, String company_Name, String required_Skills, String job_Post, String location,
            Double salary, String qualifications) {
        HR_Id = hR_Id;
        HR_Name = hR_Name;
        Company_Name = company_Name;
        Required_Skills = required_Skills;
        Job_Post = job_Post;
        Location = location;
        Salary = salary;
        Qualifications = qualifications;
    }
    // public Job(int job_Id, int hR_Id, String job_Post, String location, Double salary, String qualifications) {
    //     Job_Id = job_Id;
    //     HR_Id = hR_Id;
    //     Job_Post = job_Post;
    //     Location = location;
    //     Salary = salary;
    //     Qualifications = qualifications;
    // }
    public Job(int job_Id, int hR_Id, String hR_Name, String company_Name, String required_Skills, String job_Post,
            String location, Double salary, String qualifications) {
        Job_Id = job_Id;
        HR_Id = hR_Id;
        HR_Name = hR_Name;
        Company_Name = company_Name;
        Required_Skills = required_Skills;
        Job_Post = job_Post;
        Location = location;
        Salary = salary;
        Qualifications = qualifications;
    }
    public int getJob_Id() {
        return Job_Id;
    }
    public int getHR_Id() {
        return HR_Id;
    }
    public String getJob_Post() {
        return Job_Post;
    }
    public String getLocation() {
        return Location;
    }
    public Double getSalary() {
        return Salary;
    }
    public String getQualifications() {
        return Qualifications;
    }
    public String getHR_Name() {
        return HR_Name;
    }
    public String getCompany_Name() {
        return Company_Name;
    }
    public String getRequired_Skills() {
        return Required_Skills;
    }
    

}

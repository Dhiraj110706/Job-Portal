package model;

import java.io.FileOutputStream;

public class ApplyJob {
    int Id ; 
    int job_id ;
    int hr_id ; 
    int jobseeker_id ;
    String JobSeeker_Name ;
    String Skills;
    String Experience;
    FileOutputStream Resume ; 
    long Contact ;
    String Email ;
    public ApplyJob(int id, int job_id, int hr_id, int jobseeker_id, String jobSeeker_Name, String experience , String skills,
            FileOutputStream resume, long contact, String email) {
        Id = id;
        this.job_id = job_id;
        this.hr_id = hr_id;
        this.jobseeker_id = jobseeker_id;
        JobSeeker_Name = jobSeeker_Name;
        Skills = skills;
        Experience = experience;
        Resume = resume;
        Contact = contact;
        Email = email;
    }
    public ApplyJob(int job_id, int hr_id, int jobseeker_id, String jobSeeker_Name, String skills, String experience ,
            FileOutputStream resume, long contact, String email) {
        this.job_id = job_id;
        this.hr_id = hr_id;
        this.jobseeker_id = jobseeker_id;
        JobSeeker_Name = jobSeeker_Name;
        Skills = skills;
        Experience = experience;
        Resume = resume;
        Contact = contact;
        Email = email;
    }
    public String getExperience() {
        return Experience;
    }
    public int getId() {
        return Id;
    }
    public int getJob_id() {
        return job_id;
    }
    public int getHr_id() {
        return hr_id;
    }
    public int getJobseeker_id() {
        return jobseeker_id;
    }
    public String getJobSeeker_Name() {
        return JobSeeker_Name;
    }
    public String getSkills() {
        return Skills;
    }
    public FileOutputStream getResume() {
        return Resume;
    }
    public long getContact() {
        return Contact;
    }
    public String getEmail() {
        return Email;
    }

    

    

}

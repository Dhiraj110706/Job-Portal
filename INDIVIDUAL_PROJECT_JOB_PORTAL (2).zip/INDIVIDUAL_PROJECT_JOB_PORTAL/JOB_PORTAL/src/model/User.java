package model;
import Pages.Methods;
public class User {
    Methods m = new Methods();
    int id ;
    String Name ;
    long Contact ;
    String Email ;
    String Role ;
    public User( String name, long contact, String email, String role) {
        
        Name = name;
        Contact = contact;
        Email = email;
        Role = role;
    }
   
    public User(int id, String name, long contact, String email, String role) {
        this.id = id;
        Name = name;
        Contact = contact;
        Email = email;
        Role = role;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return Name;
    }
    public long getContact() {
        return Contact;
    }
    public String getEmail() {
        return Email;
    }
    public String getRole() {
        return Role;
    } 

    
    
}

package utils;


import java.sql.*;

import Database.DatabaseConnection;
import Database.FontColor;
import Pages.Methods;
import model.User;

public class UserList {
    DatabaseConnection db = new DatabaseConnection();
    Methods m = new Methods();
    public class Node
    {
        User user ;
        Node next ;
        Node(User user)
        {
            this.user = user ;
            this.next = null;
        }
        public User getUser() {
            return user;
        }
    
        public void setJob(User user) {
            this.user = user;
        }
    
        public Node getNext() {
            return next;
        }
    
        public void setNext(Node next) {
            this.next = next;
        }
    }
    public UserList()
    {
        try (Connection connection = db.getConnection()) {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from Users");
            while (rs.next()) {
                User u = new User(rs.getInt("ID"),rs.getString("Name"), rs.getLong("Contact"), rs.getString("Email"), rs.getString("Role"));
                add(u);
            }

        } catch (SQLException e) {
            System.out.println("Syntax Error");
        }
    }
    Node head = null  ;

    public void add(User user) {
        Node user_Node = new Node(user);  // Create a new node with the user data

        // If the list is empty, the new node becomes the head
        if (head == null) {
            head = user_Node;
        } else {
            // Otherwise, traverse to the end of the list and add the new node
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = user_Node;
        }
    }

    public boolean delete(int id)
    {
        Node previous = null;
        Node cuurent = head;
        if(cuurent.getUser().getId() == id)
        {
            head = head.next;
            printList();
            return true;
        }
        while(cuurent.getUser().getId() == id && cuurent != null)
        {
            previous = cuurent;
            cuurent = cuurent.next;
        }
        if(cuurent == null || previous == null)
        {
            return false ;
        }
        System.out.println(FontColor.RED_COLOR+"Can't delete in Queue"+FontColor.RESET_COLOR);
        previous.next = cuurent.next;
        // this.printList();
        return true;
    }

    public int search()
    {
        if(head == null )
        {
            return 0 ;
        }
        Node user_Node = head;
        
        while(user_Node.next != null)
        {
            user_Node = user_Node.next;
        }
        int id = user_Node.getUser().getId();
    
        return id ;
    }

    
    
    public void printList()
    {
        Node current = head ;
        while (current != null) {
            System.out.println(FontColor.YELLOW_COLOR);
            m.displayInBox(new String[]
            {
                "ID      :- "+current.getUser().getId(),
                "Name    :- "+current.getUser().getName() ,
                "Contact :- "+current.getUser().getContact(),
                "Email   :- "+current.getUser().getEmail(),
                "Role    :- "+current.getUser().getRole()
            });
            current = current.next;
            System.out.println(FontColor.RESET_COLOR);
        }
    }
}

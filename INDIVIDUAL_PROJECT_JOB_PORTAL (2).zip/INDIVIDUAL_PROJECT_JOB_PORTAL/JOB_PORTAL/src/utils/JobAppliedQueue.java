package utils;

import java.io.*;
import java.sql.*;
import Database.DatabaseConnection;
import Database.FontColor;
import Pages.Methods;
import model.ApplyJob;

public class JobAppliedQueue {
    Methods m = new Methods();
    DatabaseConnection db = new DatabaseConnection();
    public class Node {
        private ApplyJob job;
        private Node next;
    
        public Node(ApplyJob job) {
            this.job = job;
            this.next = null;
        }
    
        public ApplyJob getJob() {
            return job;
        }
    
        public void setJob(ApplyJob job) {
            this.job = job;
        }
    
        public Node getNext() {
            return next;
        }
    
        public void setNext(Node next) {
            this.next = next;
        }
    }
    private Node front;
    private Node rear;
    private int size;

    public JobAppliedQueue() throws IOException{
        this.front = null;
        this.rear = null;
        this.size = 0;

        String query = "SELECT * FROM applyjob a  inner join jobseeker j on j.id = a.jobseeker_id inner join users on users.id = j.user_id";
        try (Connection conn = db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int job_id = rs.getInt("Job_id");
                int hr_id = rs.getInt("HR_ID");
                int jobseeker_id = rs.getInt("JobSeeker_Id");
                String Name = rs.getString("Name");
                long contact = rs.getLong("Contact");
                String Email = rs.getString("Email");
                String Skills = rs.getString("Skills");
                String Experience = rs.getString("Experience");
                InputStream Resume = rs.getBinaryStream("Resume");
                FileOutputStream Resume_File = new FileOutputStream(new File("E:\\INDIVIDUAL_PROJECT_JOB_PORTAL\\Details\\Output_Resume\\"+Name+".pdf"));
                int i = Resume.read();
                while (i != -1) {
                    Resume_File.write(i);
                    i = Resume.read();
                }
                Resume_File.flush();

                ApplyJob applyJob = new ApplyJob(job_id, hr_id, jobseeker_id, Name, Skills,Experience ,Resume_File, contact, Email);

                enqueue(applyJob);
                
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
    public void enqueue(ApplyJob job) {
        Node newNode = new Node(job);
        if (rear == null) {
            front = newNode;
            rear = newNode;
        } else {
            rear.setNext(newNode);
            rear = newNode;
        }
        size++;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

     public void display() {
        Node current = front;
        if (isEmpty()) {
            System.out.println(FontColor.RED_COLOR+"Queue is empty"+FontColor.RESET_COLOR);
            return;
        }

        System.out.println(FontColor.MAGENTA_COLOR+"Applied Jobs in queue:"+FontColor.RESET_COLOR+FontColor.YELLOW_COLOR);
        while (current != null) {
            ApplyJob job = current.getJob();
            m.displayInBox(new String[]{
                "Job_ID          :- "+job.getJob_id(),
                "HR_ID           :- "+job.getHr_id(),
                "JobSeeker_ID    :- "+job.getJobseeker_id(),
                "Name            :- "+job.getJobSeeker_Name(),
                "Skills          :- "+job.getSkills(),
                "Experience      :- "+job.getExperience(),
                "Email           :- "+job.getEmail(),
                "Contact         :- "+job.getContact()
            });
            System.out.println(FontColor.RESET_COLOR);
            
            current = current.getNext();
        }
    }
    public int search() {
        Node current = front ;
        if(isEmpty())
        {
            return 0 ;
        }
        if(current.next == null)
        {
            return 1 ;
        }
        while (current.next != null) {
            current = current.getNext();
        }
        return current.getJob().getId();
    }

}

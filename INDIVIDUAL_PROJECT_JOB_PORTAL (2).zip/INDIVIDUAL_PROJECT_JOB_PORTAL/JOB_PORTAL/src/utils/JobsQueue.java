 package utils;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Database.DatabaseConnection;
import Database.FontColor;
import Pages.Methods;

import model.Job;

public class JobsQueue {
    Methods m = new Methods();
    DatabaseConnection db = new DatabaseConnection();
    public class Node {
        private Job job;
        private Node next;
    
        public Node(Job job) {
            this.job = job;
            this.next = null;
        }
    
        public Job getJob() {
            return job;
        }
    
        public void setJob(Job job) {
            this.job = job;
        }
    
        public Node getNext() {
            return next;
        }
    
        public void setNext(Node next) {
            this.next = next;
        }
    }
    private Node front;
    private Node rear;
    private int size;

    public JobsQueue() {
        this.front = null;
        this.rear = null;
        this.size = 0;

        String query = "SELECT * FROM job inner join hr on hr.id = job.hr_id inner join users on users.id = hr.user_id";
        try (Connection conn = db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("Job_id");
                int hr_id = rs.getInt("HR_ID");
                String hr_name = rs.getString("Name");
                String Company_name = rs.getString("Company_Name");
                String Required_Skills = rs.getString("Required_Skills");
                String title = rs.getString("Job_Post");
                String location = rs.getString("location");
                Double Salary = rs.getDouble("Salary");
                String Qualifications = rs.getString("Qualifications");

                Job job = new Job(id,hr_id,hr_name,Company_name,Required_Skills,title , location ,Salary,Qualifications);
                enqueue(job);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }

    public void enqueue(Job job) {
        Node newNode = new Node(job);
        if (rear == null) {
            front = newNode;
            rear = newNode;
        } else {
            rear.setNext(newNode);
            rear = newNode;
        }
        size++;
    }

    public Job dequeue() {
        if (isEmpty()) {
            throw new RuntimeException("Queue is empty");
        }
        Job job = front.getJob();
        front = front.getNext();
        if (front == null) {
            rear = null;
        }
        size--;
        return job;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }
    public boolean delete(int jobId) {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return false;
        }

        Node current = front;
        Node previous = null;

        while (current != null) {
            if (current.getJob().getJob_Id() == jobId) {
                if (previous == null) {
                    // The job to be deleted is at the front of the queue
                    front = current.getNext();
                } else {
                    previous.setNext(current.getNext());
                }

                if (current == rear) {
                    // The job to be deleted is at the rear of the queue
                    rear = previous;
                }

                size--;
                System.out.println("Job with ID " + jobId + " deleted from queue.");
                return true;
            }

            previous = current;
            current = current.getNext();
        }

        System.out.println("Job with ID " + jobId + " not found in queue.");
        return false;
    }
    public int search()
    {
        Node current = front ;
        if(isEmpty())
        {
            return 0 ;
        }
        while (current.next != null) {
            current = current.getNext();
        }
        return current.getJob().getJob_Id();

    }
    // public void search_Job(String Job_Post)
    // {
    //     Node current = front ;
    //     if(isEmpty())
    //     {
    //         System.out.println(FontColor.RED_COLOR+"Queue is Empty"+FontColor.RESET_COLOR);
    //         return ;
    //     }
    //     System.out.println(FontColor.CYAN_COLOR+"Job based :-  "+Job_Post+FontColor.RESET_COLOR);
    //     int n = 0 ;
    //     while (current!=null ) {
    //         Job job = current.getJob();
    //         System.out.println(job.getJob_Post());
    //         if(job.getJob_Post().contains(Job_Post))
    //         {
    //             n++;
    //             System.out.print(FontColor.YELLOW_COLOR);
                
    //             m.displayInBox(new String[]{
    //                 "Job_ID          :- "+job.getJob_Id(),
    //                 "HR_ID           :- "+job.getHR_Id(),
    //                 "HR_Name         :- "+job.getHR_Name(),
    //                 "Company_Name    :- "+job.getCompany_Name(),
    //                 "Required_Skills :- "+job.getRequired_Skills(),
    //                 "Job_Post        :- "+job.getJob_Post(),
    //                 "Location        :- "+job.getLocation(),
    //                 "Salary          :- "+job.getSalary(),
    //                 "Qualifications  :- "+job.getQualifications()
    //             });
                
    //             job = current.getNext().getJob();
    //             System.out.println(FontColor.RESET_COLOR);
    //         }
    //         // if(n == 0)
    //         // {
    //         //     System.out.println(FontColor.RED_COLOR+"No Job Found"+FontColor.RESET_COLOR);
    //         //     // current = null;
    //         // }
    //     }
    // }
    public void search_Job(String Job_Post) {
        Node current = front;
        if (isEmpty()) {
            System.out.println(FontColor.RED_COLOR + "Queue is Empty" + FontColor.RESET_COLOR);
            return;
        }
        System.out.println(FontColor.CYAN_COLOR + "Job based    :-  " + Job_Post + FontColor.RESET_COLOR);
        int n = 0;
        while (current != null) {
            Job job = current.getJob();
            if (job.getJob_Post().contains(Job_Post)) {
                n++;
                System.out.print(FontColor.YELLOW_COLOR);
    
                m.displayInBox(new String[]{
                    "Job_ID          :- " + job.getJob_Id(),
                    "HR_ID           :- " + job.getHR_Id(),
                    "HR_Name         :- " + job.getHR_Name(),
                    "Company_Name    :- " + job.getCompany_Name(),
                    "Required_Skills :- " + job.getRequired_Skills(),
                    "Job_Post        :- " + job.getJob_Post(),
                    "Location        :- " + job.getLocation(),
                    "Salary          :- " + job.getSalary(),
                    "Qualifications  :- " + job.getQualifications()
                });
    
                System.out.println(FontColor.RESET_COLOR);
            }
            current = current.getNext(); // Move to the next node
        }
    
        if (n == 0) {
            System.out.println(FontColor.RED_COLOR + "No Job Found" + FontColor.RESET_COLOR);
        }
    }
    
    public void display() {
        Node current = front;
        if (isEmpty()) {
            System.out.println(FontColor.RED_COLOR+"Queue is empty"+FontColor.RESET_COLOR);
            return;
        }

        System.out.println(FontColor.MAGENTA_COLOR+"Jobs in queue:"+FontColor.RESET_COLOR);
        while (current != null) {
            Job job = current.getJob();
            System.out.print(FontColor.YELLOW_COLOR);
            m.displayInBox(new String[]{
                "Job_ID          :- "+job.getJob_Id(),
                "HR_ID           :- "+job.getHR_Id(),
                "HR_Name         :- "+job.getHR_Name(),
                "Company_Name    :- "+job.getCompany_Name(),
                "Required_Skills :- "+job.getRequired_Skills(),
                "Job_Post        :- "+job.getJob_Post(),
                "Location        :- "+job.getLocation(),
                "Salary          :- "+job.getSalary(),
                "Qualifications  :- "+job.getQualifications()
            });
            System.out.println(FontColor.RESET_COLOR);
            
            current = current.getNext();
        }
    }
}

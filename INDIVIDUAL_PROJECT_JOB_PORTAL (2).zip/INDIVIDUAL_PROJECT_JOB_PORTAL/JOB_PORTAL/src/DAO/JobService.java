package DAO;


import java.sql.*;

import java.util.Scanner;
import Database.DatabaseConnection;
import Database.FontColor;
import Pages.Methods;
import model.Job;
import utils.JobsQueue;


public class JobService {
    Methods m = new Methods();
    Scanner sc = new Scanner(System.in);
    JobsQueue jobsQueue ;
    DatabaseConnection db = new DatabaseConnection();

    public JobService()
    {
        jobsQueue = new JobsQueue();
    }
    public void add(Job job)
    {
        int job_id = jobsQueue.search()+1 ;
        String Add_Job = "Insert into Job (Job_Id,HR_Id , Job_Post , Location , Salary , Qualifications)values(?,?,?,?,?,?)";
        try (Connection connection = db.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(Add_Job);
            pstmt.setInt(1, job_id);
            pstmt.setInt(2, job.getHR_Id());
            pstmt.setString(3,job.getJob_Post());
            pstmt.setString(4,job.getLocation());
            pstmt.setDouble(5,job.getSalary());
            pstmt.setString(6,job.getQualifications());

            int n = pstmt.executeUpdate(); 
            if(n>0)
            {
                System.out.println();
                System.out.println("Job added successfully.");
                System.out.println();
                
                Job job1 = new Job(job_id,job.getHR_Id(),job.getHR_Name(),job.getCompany_Name(),job.getRequired_Skills() ,job.getJob_Post(),job.getLocation(),job.getSalary(),job.getQualifications());
                jobsQueue.enqueue(job1);
                jobsQueue.display();
            }
            else
            {
                System.out.println("Error");
            }
        } catch (SQLException e) {
            System.out.println(e.getSQLState());
            System.out.println(e.getMessage());
            System.out.println("SQL ERROR");
        }
    }
    public void display()
    {
        jobsQueue.display();
    }
    public void search(String Job_Post)
    {
        jobsQueue.search_Job(Job_Post);
    }
    public void delete(int job_ID,int HR_ID) {
        String Delete_Job ="Delete from Job where job_id = "+job_ID+" and HR_ID = "+HR_ID;
        try (Connection connection = db.getConnection()) {
            connection.setAutoCommit(false);
            Statement stmt = connection.createStatement();
            int n = stmt.executeUpdate(Delete_Job);
            if(n>0)
            {
                System.out.println(FontColor.RED_COLOR+"""
                        Do you Want to Delete this Job Confirm ?
                        1 for Yes 
                        2 for No 
                        """+FontColor.GREEN_COLOR);
                int ans = sc.nextInt();
                System.out.print(FontColor.RESET_COLOR);
                if(ans == 1)
                {
                    connection.commit();
                    jobsQueue.delete(job_ID);
                
                }
                else if(ans == 2)
                {
                    connection.rollback();
                }
                else
                {
                    System.out.println(FontColor.RED_COLOR+"Wrong Selection You have to do again"+FontColor.RESET_COLOR);
                }
            }
            else
            {
                System.out.println();
                System.out.println(FontColor.RED_COLOR+
                                     "+____________________________________________+");
                System.out.println("|                                            |");
                System.out.println("|                  No ID found               |");
                System.out.println(  "|____________________________________________|"+FontColor.RESET_COLOR);
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println(e.getSQLState());
            System.out.println(e.getMessage());

        }
    }
    

}

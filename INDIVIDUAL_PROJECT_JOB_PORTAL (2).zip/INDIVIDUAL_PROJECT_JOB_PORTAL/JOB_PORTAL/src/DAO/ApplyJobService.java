package DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import Database.*;
import Pages.Methods;
import model.ApplyJob;

import utils.JobAppliedQueue;

public class ApplyJobService {
    Methods m = new Methods();
    Scanner sc = new Scanner(System.in);
    JobAppliedQueue applyjobsQueue ;
    DatabaseConnection db = new DatabaseConnection();
    
    public ApplyJobService()
    {
        try {
            applyjobsQueue = new JobAppliedQueue();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean add(ApplyJob job)
    {
        int id = applyjobsQueue.search()+1 ;
        String Add_Job = "Insert into  ApplyJob (Id,Job_Id,HR_Id,JobSeeker_Id)values (?,?,?,?)";
        try (Connection connection = db.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(Add_Job);
            
            pstmt.setInt(1,id);
            pstmt.setInt(2,job.getJob_id());
            pstmt.setInt(3,job.getHr_id());
            pstmt.setInt(4,job.getJobseeker_id());


            int n = pstmt.executeUpdate(); 
            if(n>0)
            {
                System.out.println(FontColor.MAGENTA_COLOR);
                System.out.println("Job Applied successfully.");
                System.out.println(FontColor.RESET_COLOR);
                
                // ApplyJob job1 = new ApplyJob(job_id, job_id, job_id, Add_Job, Add_Job, Add_Job, null, n, Add_Job);
                // applyjobsQueue.enqueue(job1);
                ApplyJob job1 = new ApplyJob(id, job.getJob_id(), job.getHr_id(),job.getJobseeker_id(), job.getJobSeeker_Name(), job.getSkills(), job.getExperience(), job.getResume(), job.getContact(), job.getEmail());
                applyjobsQueue.enqueue(job1);
                return true;
            }
            else
            {
                System.out.println(FontColor.RED_COLOR+"Error"+FontColor.RESET_COLOR);
            }
        } catch (SQLException e) {
            System.out.println(FontColor.RED_COLOR);
            System.out.println(e.getMessage());
            System.out.println("SQL ERROR"+FontColor.RESET_COLOR);
        }
        return false;
    }
    public void display()
    {
        applyjobsQueue.display();
    }
}

package DAO;

import java.sql.*;
import java.util.Scanner;

import Database.DatabaseConnection;
import Database.FontColor;
import Pages.Methods;
import model.User;
import utils.UserList;

public class UserService {
    Methods m = new Methods();
    Scanner sc = new Scanner(System.in);
    UserList userList = new UserList();
    DatabaseConnection db = new DatabaseConnection();
    
    public boolean add(User user,String Password)
    {
        int id = userList.search()+1;
        try(Connection connection = db.getConnection())
        {
            String Insert_SQL = "Insert into users(id,name,contact,email,password,role) values(?,?,?,?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(Insert_SQL);
            pstmt.setInt(1, id);
            pstmt.setString(2, user.getName());
            pstmt.setLong(3, user.getContact());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5,Password);
            pstmt.setString(6,user.getRole());

            int n = pstmt.executeUpdate();
            if(n>0)
            {
                System.out.println();
                System.out.println(FontColor.RED_COLOR+"User Inserted \n"+user.getRole()+" inserted "+FontColor.RESET_COLOR);
                System.out.println();
            }
            User user1 = new User(id,user.getName(),user.getContact(),user.getEmail(),user.getRole());
            userList.add(user1);
            return true;
        }
        catch(SQLException e)
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println("        Syntax Error       ");
            System.out.println(e.getMessage()+FontColor.RESET_COLOR);
        }
        
        return false;
    }
    public boolean delete(String Name , String Password)
    {

        String Delete_Profile = "Delete from Users where Name = '"+Name+"' and Password = '"+Password+"' ";
        try (Connection connection = db.getConnection()) {
            connection.setAutoCommit(false);
            Statement stmt = connection.createStatement();
            int id = 0 ;
            String GET = "Select Id from users where name = '"+Name+"' and password = '"+Password+"' ";
                    ResultSet rs = stmt.executeQuery(GET);
                    if(rs.next())
                    {
                        id = rs.getInt(1);
                    }
            int n = stmt.executeUpdate(Delete_Profile);
            if(n>0)
            {
                System.out.println(FontColor.RED_COLOR+"""
                        Do you Want to Delete this Job Confirm ?
                        1 for Yes 
                        2 for No 
                        """+FontColor.GREEN_COLOR);
                int ans = sc.nextInt();
                System.out.print(FontColor.RESET_COLOR);
                if(ans == 1)
                {
                    userList.delete(id);
                    connection.commit();
                    System.out.println(FontColor.RED_COLOR+"Deleted Suceesfully"+FontColor.RESET_COLOR);
                }
                else if(ans == 2)
                {
                    connection.rollback();
                }
                else
                {
                    System.out.println(FontColor.RED_COLOR+"Wrong Selection You have to do again"+FontColor.RESET_COLOR);
                }
            }
            else{
                System.out.println(FontColor.RED_COLOR);
                System.out.println("+____________________________________________+");
                System.out.println("|                                            |");
                System.out.println("|                No User found               |");
                System.out.println("|____________________________________________|");
                System.out.println(FontColor.RESET_COLOR);
            }
        } catch (SQLException e) {
            System.out.println(FontColor.RED_COLOR);
            System.out.println("        Syntax Error       ");
            System.out.println(e.getMessage()+FontColor.RESET_COLOR);
        }
        return false;
    }

    public void printUsers() {
        userList.printList();
    }
}

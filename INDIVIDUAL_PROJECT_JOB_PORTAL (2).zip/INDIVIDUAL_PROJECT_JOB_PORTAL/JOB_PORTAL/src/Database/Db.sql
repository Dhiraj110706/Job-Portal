-- -- Active: 1723220581758@@127.0.0.1@3306@job_portal



-- CREATE TABLE If not exists Users (
--   ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--   Name varchar(30) NOT NULL,
--   Contact bigint(11) NOT NULL,
--   Email varchar(30) NOT NULL,
--   Password varchar(1000) NOT NULL,
--   Role enum('JobSeeker','HR') NOT NULL DEFAULT 'JobSeeker',
--   Registration_Date timestamp NOT NULL DEFAULT current_timestamp() ,
--  PRIMARY KEY (ID) ,
--  UNIQUE KEY ID (ID),
--  UNIQUE KEY NAME (NAME,PASSWORD) 
-- );

-- CREATE TABLE If not exists JobSeeker (
--  ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  User_Id bigint(11) unsigned NOT NULL,
--  Skills varchar(1000) NOT NULL DEFAULT 'NOSKILLS',
--  Resume longblob DEFAULT NULL,
--  Experience varchar(30) DEFAULT NULL,
--  Status tinyint(1) NOT NULL DEFAULT 0,
--  PRIMARY KEY (ID),
--  UNIQUE KEY  (ID),
--  KEY Job_FK (User_Id),
--  CONSTRAINT JobSeeker_FK FOREIGN KEY (User_Id) REFERENCES users (ID) ON DELETE CASCADE ON UPDATE CASCADE
-- ) ;
-- CREATE TABLE if not exists hr (
--  ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  User_Id bigint(20) unsigned NOT NULL,
--  Company_Name varchar(30) DEFAULT 'Company',
--  Required_Skills varchar(30) DEFAULT NULL,
--  Application_Numbers int(11) DEFAULT 0,
--  PRIMARY KEY (ID),
--  UNIQUE KEY ID (ID),
--  KEY Admin_FK (User_Id),
--  CONSTRAINT Admin_FK FOREIGN KEY (User_Id) REFERENCES users (ID) ON DELETE CASCADE ON UPDATE CASCADE
-- ) ;

-- CREATE View if not EXISTS  Login As Select   Name , Role , PASSWORD  from users ; 

-- CREATE TABLE if not exists job (
--  Job_Id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  Job_Post varchar(30) NOT NULL,
--  HR_ID bigint(20) unsigned NOT NULL,
--  Location varchar(30) NOT NULL,
--  Salary double NOT NULL,
--  Qualifications varchar(50) NOT NULL,
--  PRIMARY KEY (Job_Id),
--  UNIQUE KEY Job_Id (Job_Id),
--  KEY JOB_FK (HR_ID),
--  CONSTRAINT JOB_FK FOREIGN KEY (HR_ID) REFERENCES hr (Id) ON DELETE CASCADE ON UPDATE CASCADE
-- ) ;

-- CREATE TABLE if not exists applyjob (
--  ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  Job_ID bigint(20) unsigned NOT NULL,
--  JobSeeker_ID bigint(11) unsigned NOT NULL,
--  HR_ID bigint(11) unsigned NOT NULL,
--  STATUS tinyint(1) NOT NULL DEFAULT 0,
--  PRIMARY KEY (ID),
--  UNIQUE KEY ID (ID),
--  KEY JobSeeker_FK_1 (JobSeeker_ID),
--  KEY JOB_FK_1 (Job_ID),
--  KEY HR_FK (HR_ID),
--  CONSTRAINT HR_ID FOREIGN KEY (HR_ID) REFERENCES hr (ID) ON DELETE CASCADE ON UPDATE CASCADE,
--  CONSTRAINT JOB_FK_1 FOREIGN KEY (Job_ID) REFERENCES job (Job_Id) ON DELETE CASCADE ON UPDATE CASCADE
-- );


-- CREATE TABLE if not exists job_log (
--  ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  JobPost varchar(30) NOT NULL,
--  Location varchar(30) NOT NULL,
--  HR_Name varchar(30) NOT NULL,
--  HR_Contact bigint(20) NOT NULL,
--  Deleted_At timestamp NOT NULL DEFAULT current_timestamp(),
--  PRIMARY KEY (ID),
--  UNIQUE KEY ID (ID)
-- ) ;   

-- CREATE TABLE if not exists users_log (
--  ID bigint(20) unsigned NOT NULL AUTO_INCREMENT,
--  Name varchar(30) NOT NULL,
--  Role varchar(10) NOT NULL,
--  Email varchar(30) NOT NULL,
--  Contact bigint(20) NOT NULL,
--  Register_date timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
--  Reject_date timestamp NOT NULL DEFAULT current_timestamp(),
--  PRIMARY KEY (ID),
--  UNIQUE KEY ID (ID)
-- )

-- DELIMITER $$
-- CREATE OR REPLACE PROCEDURE Check_HR (IN Name1 VARCHAR(30), IN Password1 VARCHAR(1000))
-- BEGIN
-- Select h.ID , h.Company_Name  from Hr h INNER join users u on u.ID = h.User_Id WHERE u.NAME = name1 and PASSWORD = PASSWORD1 ;
-- END$$
-- DELIMITER;


-- DELIMITER $$
-- CREATE OR REPLACE PROCEDURE Check_JobSeeker(IN Name1 VARCHAR(30), IN Password1 VARCHAR(1000))
-- BEGIN
-- Select j.ID , j.Skills  from jobseeker j INNER JOIN users u on u.ID = j.User_Id WHERE u.NAME = Name1 and u.PASSWORD = PASSWORD1;
-- END$$
-- DELIMITER;


-- DELIMITER $$
-- CREATE  OR REPLACE PROCEDURE check_login(IN Name1 VARCHAR(30), IN Password1 VARCHAR(1000))
-- BEGIN
-- SELECT * FROM login where name = name1 and PASSWORD = PASSWORD1 ;
-- END$$
-- DELIMITER;

-- CREATE OR REPLACE TRIGGER `after_job_delete` AFTER DELETE ON job
--  FOR EACH ROW BEGIN
--     -- Insert into job_log table
--     INSERT INTO job_log ( jobpost, Location, hr_name, hr_contact)
--     SELECT  OLD.job_post , OLD.location, u.name, u.contact
--     FROM HR h
--     JOIN Users u ON h.user_id = u.id
--     WHERE h.id = OLD.hr_id;
-- END

-- CREATE OR REPLACE TRIGGER `after_user_delete` AFTER DELETE ON users
--  FOR EACH ROW BEGIN
--     INSERT INTO users_log (user_id, name , Role , email, Contact , Register_date)
--     VALUES (OLD.id, OLD.name , old.Role , old.email , old.Contact , old.Registration_date);
-- END

-- CREATE OR REPLACE TRIGGER `insert_User` AFTER INSERT ON users
--  FOR EACH ROW BEGIN
-- if new.Role = 'JobSeeker'  then 
-- 	INSERT INTO jobseeker (user_id) VALUES (NEW.id);
-- ELSEIF new.Role = 'HR' then 
-- 	Insert Into Hr(user_id) VALUES (New.id);
--     End if ;
-- END


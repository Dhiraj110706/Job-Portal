package Database;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
public class DatabaseConnection {
    private static String dburl ;
    private static String[] creds ;
    private static Connection con ;
    public Connection getConnection()
    {

        dburl = "jdbc:mysql://localhost:3306/job_portal";
        try
        {
            BufferedReader credintial = new BufferedReader(new FileReader("src\\Database\\Credential.txt"));
            String line ;
            creds = new String[2];
            int i = 0 ;
            while((line = credintial.readLine())!=null)
            {
                creds[i++] = line; 
            }
            credintial.close();
            con = DriverManager.getConnection(dburl, creds[0], creds[1]);
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
        return con ;
    }
    public static void main(String[] args)
    {
        DatabaseConnection db = new DatabaseConnection();
        con = db.getConnection();
        if(con!=null)
        {
            System.out.println("Connection Done");
        }
    }
}

package Database;

public class FontColor {
    public static final String BLUE_COLOR = "\u001B[34m";
	public static final String GREEN_COLOR = "\u001B[32m";
	public static final String RESET_COLOR = "\u001B[0m";
    public static final String RED_COLOR = "\u001B[91m";
	public static final String YELLOW_COLOR = "\u001B[33m";
    public static final String MAGENTA_COLOR = "\u001B[35m";
    public static final String CYAN_COLOR = "\u001B[36m";
	public static final String COREL_COLOR = "\u001B[38;5;209m";
}

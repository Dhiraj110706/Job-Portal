package Pages;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Methods {
    // Method to hash the password using SHA-256 and encode it using Base64
    String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    // Method to display text in a box
    public void displayInBox(String[] lines) {
        int boxWidth = 80;
        String borderLine = "+" + "-".repeat(boxWidth - 2) + "+";
        
        System.out.println(borderLine);
        for (String line : lines) {
            System.out.println("| " + line + " ".repeat(boxWidth - line.length() - 3) + "|");
        }
        System.out.println(borderLine);
        
    }
    // public static void main(String[] args) {
    //     System.out.println(hashPassword("Stark@123"));;
    // }
}

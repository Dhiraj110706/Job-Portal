package Pages;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



import DAO.ApplyJobService;
import DAO.JobService;
import DAO.UserService;
import Database.DatabaseConnection;
import Database.FontColor;
import model.ApplyJob;

public class JobSeekerOperations {
    
    Scanner sc = new Scanner(System.in);
    Methods m = new Methods();
    int JOBSEEKER_ID = 0 ;
    JobService jobService = new JobService();
    UserService userService = new UserService();
    ApplyJobService applyJobService = new ApplyJobService();
    JobSeekerOperations()
    {
    }
    JobSeekerOperations(int Id,String Name , String Password)
    {
        JOBSEEKER_ID = Id ;
        System.out.println(Id);

        System.out.println(FontColor.COREL_COLOR+
                              " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                              Set UP OPERATIONS                               |");
        System.out.println(  "|______________________________________________________________________________|"+FontColor.RESET_COLOR);
        System.out.println();
        
        while (true) {
            
        
            System.out.println(FontColor.MAGENTA_COLOR+"---------------------------------Operatioins List-------------------------------"+FontColor.RESET_COLOR);
            System.out.println(FontColor.YELLOW_COLOR+"""
                    Select  1  for View   Jobs 
                    Select  2  for Search Jobs
                    Select  3  for Apply  Jobs
                    Select  4  for Cancel Application
                    Select  5  for Delete Profile
                    Select  6  for Go to  Main
                    """);

            System.out.print(FontColor.BLUE_COLOR+"Enter Choice :-       "+FontColor.GREEN_COLOR);
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                {
                    viewJobs();
                    break;
                }  
                case 2 :
                {
                    searchJobs();
                    break;
                } 
                case 3 :
                {
                    ApplyJob(JOBSEEKER_ID);
                    break;
                }
                case 4 :
                {
                    CancelApplication(JOBSEEKER_ID);
                    break;
                }
                case 5 :
                {
                    deleteProfile(Name,Password);
                    break;
                }
                case 6 :
                {
                    m.displayInBox(new String[]{
                        "                   Returning to Main  Menu      "
                    });
                    System.out.println();
                    System.out.println();
                    new Main();
                    break;
                }
                
                
                
                default:
                    break;
            }
            
        }
        
    }

    private void deleteProfile(String Name , String Password) {
        
        userService.delete(Name, Password);
        // userService.printUsers();
        
    }

    void CancelApplication(int JobSeeker_ID) {
        String Delete = "Delete from applyjob where jobseeker_id ="+JobSeeker_ID;
        DatabaseConnection db = new DatabaseConnection();
        try (Connection connection = db.getConnection()){
            Statement stmt = connection.createStatement();
            int n = stmt.executeUpdate(Delete);
            if(n>0)
            {
                System.out.println();
                System.out.println(FontColor.RED_COLOR+"Application Deleted from Id :- "+JobSeeker_ID+FontColor.RESET_COLOR);
                System.out.println();
            }
            else 
            {
                System.out.println();
                System.out.println(FontColor.RED_COLOR+"There is no application from Id :- "+JobSeeker_ID+FontColor.RESET_COLOR);
                System.out.println();
            }
        } 
        catch (SQLException e) {
            System.out.println(FontColor.RED_COLOR);
            System.out.println(e.getMessage());
            System.out.println(FontColor.RESET_COLOR);
        }
        catch(Exception e)
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println(e.getMessage());
            System.out.println(FontColor.RESET_COLOR);
        }
    }

    private void searchJobs() {
        System.out.print(FontColor.BLUE_COLOR+"Enter Post   :-     "+FontColor.GREEN_COLOR);
            sc.nextLine();
            String Post = sc.nextLine();
            System.out.print(FontColor.GREEN_COLOR);
        jobService.search(Post);
    }

    private void viewJobs()
    {
        jobService.display();
    }

    private void ApplyJob(int JobSeeker_ID)
    {
        viewJobs();
        System.out.print(FontColor.BLUE_COLOR+"Enter Job_ID :-     "+FontColor.GREEN_COLOR);
        int id = sc.nextInt();
        System.out.print(FontColor.BLUE_COLOR+"Enter HR_ID  :-     "+FontColor.GREEN_COLOR);
        int hr_id = sc.nextInt();
        System.out.println(FontColor.RESET_COLOR);
        ApplyJob job = new ApplyJob(id, hr_id, JobSeeker_ID, null, null, null, null, 0, null);
        if(applyJobService.add(job))
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println("                   Job Applied Successfully                 ");
            System.out.println(FontColor.RESET_COLOR);
        }
        
    }
    
}

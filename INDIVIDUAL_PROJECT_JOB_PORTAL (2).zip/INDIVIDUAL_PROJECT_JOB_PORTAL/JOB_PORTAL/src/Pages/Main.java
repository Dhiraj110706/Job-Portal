package Pages;
import java.util.Scanner;

import DAO.*;
import Database.FontColor;



public class Main {
    
   
    @SuppressWarnings("resource")
    public Main()
    {    
        
        Scanner  sc = new Scanner(System.in);
        System.out.println(FontColor.YELLOW_COLOR+
                             "+------------------------------------------------------------------------------+");
        System.out.println("|                                                                              |");
        System.out.println("|                          Hi Welcome to our Job_Portal                        |");
        System.out.println("|                                                                              |");
        System.out.println(  "+------------------------------------------------------------------------------+"+FontColor.RESET_COLOR);
        System.out.println();
        
         
        
        while (true) {
            
        
            System.out.println();
        
            System.out.println(FontColor.COREL_COLOR+
                               "+------------------------------------------------------------------------------+");
            System.out.println("|                                                                              |");
            System.out.println("|                          Select 1 For Registration                           |");
            System.out.println("|                          Select 2 For JobSeeker                              |");
            System.out.println("|                          Select 3 For HR                                     |");
            System.out.println("|                          Select 4 For View All Users                         |");
            System.out.println("|                          Select 5 For View All Jobs                          |");
            System.out.println("|                          Select 6 For View All Applied Jobs                  |");
            System.out.println("|                                                                              |");
            System.out.println(  "+------------------------------------------------------------------------------+"+ FontColor.RESET_COLOR);
            System.out.println();

            
            int choice  = 0;
            boolean flag = false ;
            while (!flag || choice == 0 ) {
                try
                {
                    System.out.print(FontColor.CYAN_COLOR+"Enter Choice =>     "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
                    choice = sc.nextInt();
                    System.out.println(FontColor.RESET_COLOR);
                    flag = true;
                }
                catch(Exception e)
                {
                    sc.nextLine();
                    System.out.println(FontColor.RED_COLOR);
                    System.out.println("          Select Correct Choice        ");
                    System.out.println(FontColor.RESET_COLOR);
                    flag = false;
                    continue;
                }
            }
            switch (choice) {
                case 1:
                {
                    new Registration();
                    
                    break ;
                }
                case 2:
                {
                    new JobSeeker();
                    break;
                }
                case 3 :
                {
                    new HR();
                    break;
                }
                case 4 :
                {
                    new UserService().printUsers();
                    
                    break;
                }
                case 5 :
                {
                    new JobService().display();
                    break;
                    
                }
                case 6 :
                {
                new ApplyJobService().display();
                
                break;
                }
                case 10 :
                {
                    System.exit(1);
                }
                default:
                {
                    System.out.println(FontColor.RED_COLOR);
                    System.out.println("          Select Correct Choice        ");
                    System.out.println(FontColor.RESET_COLOR);
                    break;
                }
            }
        }
        
    }
}

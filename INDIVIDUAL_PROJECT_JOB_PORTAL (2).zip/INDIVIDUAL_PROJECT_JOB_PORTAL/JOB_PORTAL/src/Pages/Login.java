package Pages;
import java.sql.*;
import java.util.Scanner;
import Database.DatabaseConnection;
import Database.FontColor;

public class Login {
  
    
    @SuppressWarnings("resource")
    Login() 
    {
        
        Methods m = new Methods();
        Scanner scanner = new Scanner(System.in);

        DatabaseConnection db = new DatabaseConnection() ;
        System.out.println(FontColor.COREL_COLOR+
                             " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                            Welcome to Login                                  |");
        System.out.println(  "|______________________________________________________________________________|" + FontColor.RESET_COLOR);
        System.out.println();
        System.out.println(FontColor.MAGENTA_COLOR+"----------------------------------Authentic YourSelf----------------------------"+FontColor.RESET_COLOR);
        System.out.println();
        
        
        System.out.print(FontColor.BLUE_COLOR+"Name             :-       "+FontColor.GREEN_COLOR);
        String Name = scanner.nextLine();
        System.out.print(FontColor.BLUE_COLOR+"Password         :-       "+FontColor.GREEN_COLOR);
        String Password = scanner.nextLine();
        System.out.println(FontColor.RESET_COLOR);

        try(Connection connection =  db.getConnection())
        {
            String CHECK_SQL ="{call Check_Login(?,?)}";
            
            // String CHECK_SQL = "SELECT * from "+Role+" Inner Join Users where Name ='"+Name+"' AND Password = '"+m.hashPassword(Password)+"' ;";
            
            CallableStatement cstmt = connection.prepareCall(CHECK_SQL);
            cstmt.setString(1, Name);
            cstmt.setString(2, m.hashPassword(Password));
            // Statement stmt = connection.createStatement();

            ResultSet rs = cstmt.executeQuery();
            String Role = "" ;
            if(rs.next())
            {
                Role = rs.getString(2); 
                
                if(Role.equalsIgnoreCase("JobSeeker"))
                {
                    new JobSeeker(Name, m.hashPassword(Password), Role);
                }
                else if(Role.equalsIgnoreCase("HR"))
                {
                    new HR(Name, m.hashPassword(Password), Role);
                }
                System.out.println("True");
            }
            else
            {
                throw new AuthenticationException("No such User ");

            }
                
            
            
        }
        catch(SQLException e)
        {
            System.out.println();
            System.out.println(e.getMessage());
            System.out.println();
        }
        catch(AuthenticationException e)
        {
            System.out.println();
            System.out.println(e.getMessage());
            System.out.println();
        }

       

    }
    
}
class AuthenticationException extends Exception
{
    AuthenticationException(String s)
    {
        super(s);
    }

}

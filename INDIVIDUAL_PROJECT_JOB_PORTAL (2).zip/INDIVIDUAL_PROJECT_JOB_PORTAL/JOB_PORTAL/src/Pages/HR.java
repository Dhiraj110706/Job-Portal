package Pages;

import java.sql.*;
import java.util.Scanner;

import javax.swing.JOptionPane;

import Database.DatabaseConnection;
import Database.FontColor;

public class HR {
    static Scanner sc = new Scanner(System.in);


    public HR() 
    {
        System.out.println(FontColor.COREL_COLOR+
                              " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                            HI Welcome HR !                                   |");
        System.out.println(  "|______________________________________________________________________________|"+FontColor.RESET_COLOR);

        new Login();
    }

    public HR(String Name , String Password , String Role)
    {


        DatabaseConnection db = new DatabaseConnection();
        // System.out.println("HR");
        try(Connection connection = db.getConnection())
        {
            String Check_HR = "{call Check_HR(?,?)}";
            CallableStatement cstmt = connection.prepareCall(Check_HR);
            cstmt.setString(1,Name);
            cstmt.setString(2,Password);
            ResultSet rs = cstmt.executeQuery();

            // String CHECK_SQL = "SELECT * from "+Role+" where Name ='"+Name+"' AND Password = '"+Password+"' ";
            // Statement stmt = connection.createStatement();
            // ResultSet rs = stmt.executeQuery(CHECK_SQL);
            // System.out.println("HR");
            while(rs.next())
            {
                if(rs.getString("Company_Name").equals("Company"))
                {   
                    CompleteDetails(Name, Password);
                }
                else
                {
                    // System.out.println(rs.getInt(1));
                    new HROperations(rs.getInt("ID"),Name,Password);
                    break;
                }
            }
        }
        catch(SQLException e)
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println(e.getMessage());
            System.out.println(FontColor.RESET_COLOR);
        }
        catch(Exception e)
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println(e.getMessage());
            System.out.println(FontColor.RED_COLOR);
        }
    }
    private int CompleteDetails(String Name , String Password)throws  InterruptedException
    {
        int Id  = 0;
        DatabaseConnection db = new DatabaseConnection();
        System.out.println(FontColor.COREL_COLOR+
                             " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                              Complete Your Profile  !                        |");
        System.out.println(  "|______________________________________________________________________________|"+FontColor.RESET_COLOR);
        System.out.println();

        System.out.print(FontColor.BLUE_COLOR+"Enter Company Name   :-        "+FontColor.GREEN_COLOR);
        String Company_Name = sc.nextLine();

        System.out.print(FontColor.BLUE_COLOR+"Enter Required Skils :-        "+FontColor.GREEN_COLOR);
        String Required_Skills = sc.nextLine();
        System.out.print(FontColor.RESET_COLOR);
        try(Connection connection =  db.getConnection())
        {
            
            
            String Complete_SQL = "UPDATE HR H Inner Join Users U on U.ID = H.User_ID SET H.Company_Name = ?, H.Required_Skills = ? WHERE U.Name = ? AND U.Password = ?";

            PreparedStatement pstmt = connection.prepareStatement(Complete_SQL);
            pstmt.setString(1, Company_Name);
            pstmt.setString(2, Required_Skills);
            pstmt.setString(3, Name);
            pstmt.setString(4, Password);

            // Execute the update
            pstmt.executeUpdate();
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("Select h.ID from HR h Inner Join Users u where u.name = '"+Name +" 'And u.Password = '"+Password+"'");
            while (rs.next()) {
                Id = rs.getInt(1);
            }
            Methods m  =new Methods();
            System.out.println(FontColor.YELLOW_COLOR);
            m.displayInBox(new String[]{
                "ID                 : " + Id,
                "Name               : " + Name,
                "Company_Name       : " + Company_Name,
                "Required_Skills    : " + Required_Skills
            });
            System.out.print(FontColor.RESET_COLOR);
            new HROperations(Id,Name,Password);
            
            
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "SQL ERROR", JOptionPane.ERROR_MESSAGE);
        }
        return Id ;

    }
}

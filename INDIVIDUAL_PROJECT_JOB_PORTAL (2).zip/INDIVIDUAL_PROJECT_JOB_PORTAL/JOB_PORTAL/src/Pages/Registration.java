package Pages;

import java.util.Scanner;
import javax.swing.JFrame;


import model.User;



import DAO.UserService;
import Database.*;

public class Registration {
    JFrame frame = new JFrame();
    static Scanner sc ;
    public Registration() {

        Methods m = new Methods();
        frame.setVisible(true);
        frame.dispose();
         sc = new Scanner(System.in);

        System.out.println(FontColor.RED_COLOR+
                             " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                            Welcome to Registration                           |");
        System.out.println(  "|______________________________________________________________________________|"+FontColor.RESET_COLOR);

        System.out.println();
        System.out.println(FontColor.MAGENTA_COLOR+"----------------------------------Enter Your Details----------------------------"+FontColor.RESET_COLOR);
        System.out.println();

        // Input Name
        System.out.print(FontColor.CYAN_COLOR+"Enter Name       :-       "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
        String Name = sc.nextLine();
        System.out.print(FontColor.RESET_COLOR);
        // Input Contact Number
        long Contact = 0;
        while (Contact == 0) {
            try {
                System.out.print(FontColor.CYAN_COLOR+"Enter Contact No :-       "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
                String temp_Contact = sc.nextLine();
                System.out.print(FontColor.RESET_COLOR);
                if (temp_Contact.charAt(0) == '0') {
                    throw new ContactException(FontColor.RED_COLOR+"Contact number should not start with 0."+FontColor.RESET_COLOR);
                }
                boolean flag = false;
                if (temp_Contact.length() == 10) {
                    for (int i = 0; i < temp_Contact.length(); i++) {
                        if (!Character.isDigit(temp_Contact.charAt(i))) {
                            flag = true;
                            throw new ContactException("Only digits 0-9 are allowed.");
                        }
                    }
                } else {
                    throw new ContactException("Length must be exactly 10");
                }

                if (!flag) {
                    Contact = Long.parseLong(temp_Contact);
                }
            } catch (ContactException e) {
                System.out.println(FontColor.RED_COLOR+"Contact Number is not in Perfect Format"+FontColor.RESET_COLOR);
            }
        }

        // Input Email
        String Email = null;
        while (true) {
            
        System.out.print(FontColor.CYAN_COLOR+"Enter Email      :-       "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
        Email = sc.nextLine();
        System.out.print(FontColor.RESET_COLOR);
        if(Email.equals("@gmail.com"))
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println("!!! Enter Valid Email ID !!!");
            System.out.println(FontColor.RESET_COLOR);
            continue;
        }
        if(Email.contains("@gmail.com"))
        {
            break;
        }
        else
        {
            System.out.println(FontColor.RED_COLOR);
            System.out.println("!!! Enter Valid Email ID !!!");
            System.out.println(FontColor.RESET_COLOR);
        }
        }

        // Input Role
        int n = 0;
        String Role = "";
        while (n != 1 && n != 2) {
            System.out.println(FontColor.CYAN_COLOR+"""
                Please Select Role
                1. JobSeeker
                2. HR""");
            System.out.print("Role             :-       "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
            n = sc.nextInt();
            System.out.print(FontColor.RESET_COLOR);
            sc.nextLine();  // Consume the newline character
            if (n == 1) {
                Role = "JobSeeker";
            } else if (n == 2) {
                Role = "HR";
            } else {
                System.out.println(FontColor.RED_COLOR);
                System.out.println("Select Correct Role");
                System.out.println(FontColor.RESET_COLOR);
            }
        }

        // Input Password
        System.out.print(FontColor.CYAN_COLOR+"Enter Password   :-       "+FontColor.RESET_COLOR+FontColor.GREEN_COLOR);
        String Password = sc.nextLine();
        System.out.print(FontColor.RESET_COLOR);

        

        User user = new User( Name, Contact, Email, Role);
        UserService userService = new UserService();
        userService.add(user, m.hashPassword(Password));

        System.out.println();
        System.out.println(FontColor.MAGENTA_COLOR+"-------------------------------------------------------------------------------"+FontColor.RESET_COLOR);
        System.out.println();
        // userService.printUsers();
        System.out.println();
        System.out.println(FontColor.BLUE_COLOR+"------------------------------------Your Details-------------------------------"+FontColor.RESET_COLOR+FontColor.YELLOW_COLOR);
         // Display all details in a box
         m.displayInBox(new String[]{
            "Name     : " + Name,
            "Contact  : " + Contact,
            "Email    : " + Email,
            "Role     : " + Role,
            "Password : " + Password
        });
        System.out.print(FontColor.RESET_COLOR);;

        System.out.println();
        System.out.println(FontColor.YELLOW_COLOR);
        
        m.displayInBox(new String[]{
            "     Returning to Main  Menu      "
        });
        System.out.println(FontColor.RESET_COLOR);
        System.out.println();
        new Main();
        
    }
    

    
}

class ContactException extends Exception {
    ContactException(String s) {
        super(s);
    }
}

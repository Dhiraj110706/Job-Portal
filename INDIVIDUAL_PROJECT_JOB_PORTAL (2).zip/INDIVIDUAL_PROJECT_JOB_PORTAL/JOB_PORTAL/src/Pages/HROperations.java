package Pages;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import DAO.JobService;
import DAO.UserService;
import Database.DatabaseConnection;
import Database.FontColor;
import model.Job;

public class HROperations {
    JFrame frame = new JFrame();
    Scanner  sc ;
    Methods m = new Methods();
    int HR_Id  =0;
    JobService jobService = new JobService();
    UserService userService = new UserService();
    
    HROperations(int Id, String Name , String Password)  
    {
        sc = new Scanner(System.in);
        HR_Id = Id;
        // System.out.println(HR_Id);
        while (true)        
        {   
            frame.setVisible(true);
            frame.dispose();
            System.out.println(FontColor.COREL_COLOR+
                                 " ______________________________________________________________________________ ");
            System.out.println("|                                                                              |");
            System.out.println("|                              Set UP OPERATIONS                               |");
            System.out.println(  "|______________________________________________________________________________|"+FontColor.MAGENTA_COLOR);
            System.out.println();
            
            System.out.println("---------------------------------Operatioins List-------------------------------"+FontColor.YELLOW_COLOR);
            System.out.println("""
                    Select  1 for Add     Jobs 
                    Select  2 for View    Users
                    Select  3 for Accept  User
                    Select  4 for Reject  User
                    Select  5 for Delete  Job
                    Select  6 for Delete  Profile
                    Select  7 for Return  Main
                    """+FontColor.MAGENTA_COLOR);
            System.out.println("--------------------------------------------------------------------------------"+FontColor.MAGENTA_COLOR);
            System.out.println(FontColor.BLUE_COLOR);
            System.out.print("Enter Choice :-       "+FontColor.GREEN_COLOR);
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                {
                    addJobs(HR_Id);
                    break;
                }
                case 2 :
                {
                    viewUsers();
                    break;
                }
                case 3 :
                {
                    AcceptUsers();
                    break;
                }
                case 4 :
                {
                    RejectUsers();
                    break ;
                }
                case 5 :
                {
                    deleteJob();
                    break;
                }
                case 6 :
                {
                    deleteProfile(Name , Password);
                    break;
                }
                case 7 :
                {
                    System.out.println(FontColor.YELLOW_COLOR);
                    m.displayInBox(new String[]{
                        "     Returning to Main  Menu      "
                    });
                    System.out.println(FontColor.RESET_COLOR);
                    System.out.println();
                    new Main();
                    break ;
                }
            
                default:
                    break;
            }
        }
        
        
    }
    
    private void deleteProfile(String Name , String Password) {
        userService.delete(Name, Password);
        userService.printUsers();
    }
    private void deleteJob() {
        System.out.print(FontColor.BLUE_COLOR+"Enter Job_ID          :-     "+FontColor.GREEN_COLOR);
        int Job_ID = sc.nextInt();
        System.out.print(FontColor.RESET_COLOR);
        jobService.delete(Job_ID,HR_Id);
        jobService.display();
               
    }
    private void RejectUsers() {
        System.out.print(FontColor.BLUE_COLOR+"Enter JobSeeker_ID    :-     "+FontColor.GREEN_COLOR);
        int id = sc.nextInt();
        System.out.print(FontColor.RESET_COLOR);
        String Reject  = "Update JobSeeker set Status ="+false+" where ID = "+id;
        DatabaseConnection db = new DatabaseConnection();
        try (Connection connection = db.getConnection() ){
            Statement stmt = connection.createStatement();
            stmt.executeUpdate(Reject);

            JobSeekerOperations j = new JobSeekerOperations();
            j.CancelApplication(id);
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "SQL ERROR", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void AcceptUsers() {
        System.out.print(FontColor.BLUE_COLOR+"Enter JobSeeker_ID        :-     "+FontColor.GREEN_COLOR);
        int id = sc.nextInt();
        System.out.print(FontColor.RESET_COLOR);
        String Accept = "Update JobSeeker set Status ="+true+" where ID = "+id;
        DatabaseConnection db = new DatabaseConnection();
        try (Connection connection = db.getConnection() ){
            Statement stmt = connection.createStatement();
            stmt.executeUpdate(Accept);

            JobSeekerOperations j = new JobSeekerOperations();
            j.CancelApplication(id);
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "SQL ERROR", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        

    }
    private void viewUsers() {
        DatabaseConnection db = new DatabaseConnection();
        String Display_SQL = "Select * from ApplyJob a Inner Join job h on h.HR_ID = a.HR_ID Inner Join JobSeeker j on a.JobSeeker_ID = j.ID Inner Join Users u on u.ID = j.User_Id where h.HR_ID = "+HR_Id+"; " ;
        try(Connection connection = db.getConnection())
        {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(Display_SQL);

            if(!rs.next())
            {                                                 
                System.out.println(FontColor.RED_COLOR+"No users applied "+FontColor.RESET_COLOR);
            }
            
            while(rs.next())
            {
                System.out.println(rs.getString("Name"));
                System.out.print(FontColor.YELLOW_COLOR);
                m.displayInBox(new String[] {
                    "Job_Id          :- "+rs.getInt("Job_Id")  ,
                    "JobSeeker_Id    :- "+rs.getInt("JobSeeker_Id"),
                    "Job_Post        :- "+rs.getString("Job_Post"),
                    "User Name       :- "+rs.getString("Name"),
                    "User_Experience :- "+rs.getString("Experience"),
                    "Location        :- "+rs.getString("Location"),
                    "Qualification   :- "+rs.getString("Qualifications"),
                    "Expected Salary :- "+rs.getDouble("Salary"),
                    "Contact         :- "+rs.getLong("Contact"),
                    "Email           :- "+rs.getString("Email")
                });
                System.out.println(FontColor.RESET_COLOR);
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "SQL ERROR", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void addJobs(int HR_ID)
    {
        // System.out.println();
        sc.nextLine();
        System.out.println();
        System.out.print(FontColor.BLUE_COLOR+"Enter Job_Post       :-       "+FontColor.GREEN_COLOR);
        String Job_Post = sc.nextLine();
        System.out.print(FontColor.BLUE_COLOR+"Enter Location       :-       "+FontColor.GREEN_COLOR);
        String Location = sc.nextLine();
        System.out.print(FontColor.BLUE_COLOR+"Enter Salary         :-       "+FontColor.GREEN_COLOR);
        double Salary = sc.nextDouble();
        sc.nextLine();
        System.out.print(FontColor.BLUE_COLOR+"Enter Qualifications :-       "+FontColor.GREEN_COLOR);
        String Qualifications	= sc.nextLine();
        System.out.print(FontColor.RESET_COLOR);
        Job job = new Job(HR_ID, Job_Post, Location, Salary, Qualifications);
        jobService.add(job);
    }
}

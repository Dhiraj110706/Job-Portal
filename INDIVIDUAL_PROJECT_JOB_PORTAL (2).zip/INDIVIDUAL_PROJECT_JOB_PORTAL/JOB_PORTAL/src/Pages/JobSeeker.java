package Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

import javax.swing.JOptionPane;

import Database.DatabaseConnection;
import Database.FontColor;

public class JobSeeker {
    static Scanner sc = new Scanner(System.in);
   
    int JobSeeker_ID = 0 ;
    public JobSeeker()
    {
        System.out.println(FontColor.YELLOW_COLOR+
                             " ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                            HI Welcome JobSeeker !                            |");
        System.out.println(  "|______________________________________________________________________________|"+FontColor.RESET_COLOR);

        new Login();
    }
    public JobSeeker(String Name , String Password , String Role ) throws SQLException
    {
       
      
       DatabaseConnection db = new DatabaseConnection();
       try(Connection connection =  db.getConnection())
        {

            String Check_JobSeeker = "{call Check_JobSeeker(?,?)}";
            CallableStatement cstmt = connection.prepareCall(Check_JobSeeker);
            cstmt.setString(1, Name);
            cstmt.setString(2, Password);
            ResultSet rs = cstmt.executeQuery();
            
            
        
            while(rs.next())
            {
                JobSeeker_ID = rs.getInt(1);
                if(rs.getString("Skills").equals("NOSKILLS"))
                {   
                    CompleteDetails(Name, Password);
                }
                else
                {
                    new JobSeekerOperations(JobSeeker_ID,Name,Password);
                }
            }

        }
        catch(SQLException e)
        {
            System.out.println();
            System.out.println(e.getMessage());
            System.out.println();
        }
        catch(Exception e)
        {
           System.out.println();
            System.out.println(e.getMessage());
            System.out.println();
        }
        
        
        
    }
    private void CompleteDetails(String Name , String Password) throws InterruptedException
    {
        DatabaseConnection db = new DatabaseConnection();
        System.out.println(" ______________________________________________________________________________ ");
        System.out.println("|                                                                              |");
        System.out.println("|                              Complete Your Profile  !                        |");
        System.out.println("|______________________________________________________________________________|");
        System.out.println();
        System.out.print(FontColor.BLUE_COLOR+"Skills       :-        "+FontColor.GREEN_COLOR);
        String Skills = sc.nextLine();
        FileInputStream Resume = null;
        while (Resume == null) {
            
        
            System.out.print(FontColor.BLUE_COLOR+"Resume       :-        ");
            String Resume_File_Adress = "E:\\INDIVIDUAL_PROJECT_JOB_PORTAL\\Details\\Input_Resume\\" ;
            Resume_File_Adress = Resume_File_Adress+ sc.nextLine();
            System.out.println(FontColor.RESET_COLOR);
            File Resume_File = new File(Resume_File_Adress);
            try
            {
                Resume  = new FileInputStream(Resume_File);
            }
            catch(IOException e)
            {
                System.out.println(FontColor.RED_COLOR+e.getMessage()+FontColor.RESET_COLOR);
            }
        }
        System.out.print(FontColor.BLUE_COLOR+"Experience   :-        "+FontColor.GREEN_COLOR);
        String Experience = sc.nextLine();
        System.out.println(FontColor.RESET_COLOR);

        try(Connection connection =  db.getConnection())
        {
            

            String Complete_SQL = "UPDATE JobSeeker j  Join Users u on j.user_id = u.id SET j.Skills = ?, j.Resume = ?, j.Experience = ? WHERE u.Name = ? AND u.Password = ?";

            PreparedStatement pstmt = connection.prepareStatement(Complete_SQL);
            pstmt.setString(1, Skills);
            pstmt.setBlob(2, Resume);
            pstmt.setString(3, Experience);
            pstmt.setString(4, Name);
            pstmt.setString(5, Password);

            // Execute the update
            int row = pstmt.executeUpdate();
            
            if(row>0)
            {
                System.out.println(FontColor.YELLOW_COLOR+"Profile Completed!!"+FontColor.RESET_COLOR);
                new JobSeekerOperations(JobSeeker_ID,Name,Password);
            }
            
            
            
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(), "SQL ERROR", JOptionPane.ERROR_MESSAGE);
        }
        

        
        
    }
}
